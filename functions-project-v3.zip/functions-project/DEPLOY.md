# הוראות פריסה ידנית — Cloud Functions

זה ההסבר אם אתה רוצה לפרוס בלי Firebase CLI (דרך הממשק).

⚠️ **חשוב:** Cloud Functions **לא ניתנות לפריסה** דרך Firebase Console בלבד. אתה **חייב** את ה-CLI.

## למה אי-אפשר ידנית?

Cloud Functions זה קוד שרץ בשרת. בניגוד ל-Firestore Rules או Realtime Database (שזה JSON), Functions זה קבצי Node.js שצריך לארוז ולהעלות בצורה ספציפית.

**אופציות שיש לך:**

### אופציה 1 (מומלצת): חכה לאישור של ה-IT
- תבקש מה-IT שלך להתקין:
  1. **Node.js LTS** מ-[nodejs.org](https://nodejs.org)
  2. אחר כך תוכל להריץ `npm install -g firebase-tools` בעצמך

### אופציה 2: בקש מ-IT להתקין רק את Firebase CLI
- אפשר להתקין Firebase CLI כתוכנית עצמאית בלי Node.js
- הקובץ נמצא ב: https://firebase.tools/bin/win/instant/latest
- **זה קובץ exe יחיד** — לא דורש הרשאות מתקדמות
- IT יוכל לאשר את זה בקלות יחסית

### אופציה 3: השתמש ב-Cloud Shell של Google (חינמי, בלי התקנות!)
- גש ל-https://shell.cloud.google.com
- תיכנס עם אותו חשבון Google
- שם כבר מותקנים Node.js ו-Firebase CLI
- אני אתן לך הוראות מפורטות איך לפרוס מהדפדפן

**אופציה 3 היא הכי טובה למצב שלך** - לא צריך להתקין כלום במחשב, הכל בענן.

---

## פריסה דרך Google Cloud Shell (אופציה 3)

### שלב 1: פתח Cloud Shell
1. גש ל-https://shell.cloud.google.com
2. תיכנס עם החשבון של Google (זה שמחובר ל-Firebase שלך)
3. תקבל טרמינל בתוך הדפדפן

### שלב 2: התקן את firebase-tools (חד-פעמי)
בטרמינל הקלד:
```
npm install -g firebase-tools
```

### שלב 3: התחבר
```
firebase login --no-localhost
```

זה יתן לך URL — תפתח אותו, תאשר, ותעתיק את הקוד בחזרה לטרמינל.

### שלב 4: צור תיקיית הפרויקט והעלה את הקבצים
תצטרך להעלות את התיקייה `functions-project` שאני אכין לך כ-ZIP.

ב-Cloud Shell יש כפתור בפינה הימנית-עליונה ⋮ → "Upload" — תוכל להעלות את ה-ZIP.

אחרי שהעלאת:
```
unzip functions-project.zip
cd functions-project
firebase deploy --only functions
```

זה יקח 2-3 דקות בפעם הראשונה (מתקין dependencies + פורס).

אחרי שמסתיים תראה משהו כמו:
```
✔  functions[onAdminBroadcast(europe-west1)] Successful create operation.
✔  functions[onRouletteSpin(europe-west1)] Successful create operation.
...
✔  Deploy complete!
```

זהו! ההתראות עכשיו פעילות.
