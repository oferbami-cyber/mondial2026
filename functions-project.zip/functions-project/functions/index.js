/**
 * Cloud Functions for תחזיות מונדיאל 26
 *
 * Functions:
 *   1. onAdminBroadcast       - Manual notifications from admins
 *   2. onRouletteSpin         - "Your turn!" when wheel stops
 *   3. scheduledMatchReminders - Cron every 5min, alerts 30min before match
 *   4. scheduledDailySummary  - Cron at 23:00, daily summary
 *   5. onRoundStart           - When tournament phase changes
 *
 * Region: europe-west1 (matches your Realtime DB)
 */

const { onValueCreated, onValueUpdated } = require("firebase-functions/v2/database");
const { onSchedule } = require("firebase-functions/v2/scheduler");
const { setGlobalOptions } = require("firebase-functions/v2");
const admin = require("firebase-admin");
const logger = require("firebase-functions/logger");

admin.initializeApp();
const db = admin.database();
const messaging = admin.messaging();

// Set region for all functions to match your DB
setGlobalOptions({ region: "europe-west1" });

// ================================================================
// HELPERS
// ================================================================

/**
 * Get all FCM tokens for a list of player IDs, optionally filtered by
 * a specific notification preference. Returns flat array of tokens.
 */
async function getTokensForPlayers(playerIds, prefKey = null) {
  const tokens = [];
  for (const pid of playerIds) {
    const snap = await db.ref(`players/${pid}`).once("value");
    const player = snap.val();
    if (!player) continue;

    // Check if this notification type is enabled for this player
    if (prefKey) {
      const enabled = player.notifPrefs?.[prefKey];
      if (enabled === false) continue; // default to true if undefined
    }

    // Collect all device tokens for this player
    const fcmTokens = player.fcmTokens || {};
    for (const deviceId of Object.keys(fcmTokens)) {
      const t = fcmTokens[deviceId]?.token;
      if (t) tokens.push({ token: t, playerId: pid, deviceId });
    }
  }
  return tokens;
}

/**
 * Get tokens for ALL players (used for broadcast notifications)
 */
async function getAllTokens(prefKey = null) {
  const snap = await db.ref("players").once("value");
  const players = snap.val() || {};
  return getTokensForPlayers(Object.keys(players), prefKey);
}

/**
 * Send notifications to a list of tokens. Handles cleanup of invalid tokens.
 * Returns { sent, failed, cleaned }
 */
async function sendToTokens(tokensWithMeta, payload) {
  if (!tokensWithMeta.length) {
    return { sent: 0, failed: 0, cleaned: 0 };
  }

  const tokens = tokensWithMeta.map((t) => t.token);
  let sent = 0, failed = 0, cleaned = 0;

  // FCM sendEachForMulticast accepts up to 500 tokens at once
  const BATCH = 500;
  for (let i = 0; i < tokens.length; i += BATCH) {
    const batch = tokens.slice(i, i + BATCH);
    const batchMeta = tokensWithMeta.slice(i, i + BATCH);

    const message = {
      tokens: batch,
      notification: payload.notification,
      data: payload.data || {},
      webpush: {
        fcmOptions: { link: payload.data?.url || "/" },
        notification: {
          icon: "/icons/icon-192.png",
          badge: "/icons/icon-192.png",
          tag: payload.data?.tag || "mondial26",
          requireInteraction: false,
          dir: "rtl",
          lang: "he",
        },
      },
    };

    try {
      const response = await messaging.sendEachForMulticast(message);
      sent += response.successCount;
      failed += response.failureCount;

      // Clean up invalid tokens
      for (let j = 0; j < response.responses.length; j++) {
        const result = response.responses[j];
        if (!result.success) {
          const errCode = result.error?.code || "";
          if (errCode.includes("registration-token-not-registered") ||
              errCode.includes("invalid-argument") ||
              errCode.includes("invalid-registration-token")) {
            const meta = batchMeta[j];
            try {
              await db.ref(`players/${meta.playerId}/fcmTokens/${meta.deviceId}`).remove();
              cleaned++;
              logger.info(`Removed invalid token for player ${meta.playerId} / device ${meta.deviceId}`);
            } catch (e) {
              logger.error("Failed to remove invalid token", e);
            }
          } else {
            logger.warn(`Send failed: ${errCode}`, result.error?.message);
          }
        }
      }
    } catch (e) {
      logger.error("Batch send error", e);
      failed += batch.length;
    }
  }

  return { sent, failed, cleaned };
}

// ================================================================
// 1. onAdminBroadcast - Manual notifications from admins
// ================================================================
// Triggered when admin writes to /adminBroadcasts/{id}
exports.onAdminBroadcast = onValueCreated(
  { ref: "/adminBroadcasts/{broadcastId}" },
  async (event) => {
    const broadcastId = event.params.broadcastId;
    const broadcast = event.data.val();
    if (!broadcast) return;

    const { title, body, sentBy, targetPlayers } = broadcast;
    if (!title || !body) {
      logger.warn("Broadcast missing title/body, skipping", { broadcastId });
      return;
    }

    logger.info(`Broadcast ${broadcastId} from ${sentBy}: "${title}"`);

    let tokens;
    if (targetPlayers && Array.isArray(targetPlayers) && targetPlayers.length > 0) {
      tokens = await getTokensForPlayers(targetPlayers, "admin");
    } else {
      // Send to all who have admin notifications enabled
      tokens = await getAllTokens("admin");
    }

    const result = await sendToTokens(tokens, {
      notification: { title, body },
      data: { tag: "admin-msg", url: "/", type: "admin" },
    });

    // Update broadcast record with result
    await db.ref(`/adminBroadcasts/${broadcastId}`).update({
      status: "sent",
      sentAt: admin.database.ServerValue.TIMESTAMP,
      result: result,
    });

    logger.info(`Broadcast ${broadcastId} complete`, result);
  }
);

// ================================================================
// 2. onRouletteSpin - "Your turn!" when previous user finishes
// ================================================================
// Triggered when roulette.currentTurn changes (after spin completes)
exports.onRouletteSpin = onValueUpdated(
  { ref: "/state/roulette" },
  async (event) => {
    const before = event.data.before.val() || {};
    const after = event.data.after.val() || {};

    // Only notify when spinningPhase transitions to "selected"
    // AND currentTurn actually changed
    const spinFinished = before.spinningPhase !== "selected" && after.spinningPhase === "selected";
    if (!spinFinished) return;

    const currentPlayerId = after.currentTurn;
    if (!currentPlayerId) return;

    logger.info(`Roulette spin finished - notifying player ${currentPlayerId}`);

    const tokens = await getTokensForPlayers([currentPlayerId], "roulette");
    if (!tokens.length) {
      logger.info(`No tokens for player ${currentPlayerId}`);
      return;
    }

    const round = after.round || 1;
    const result = await sendToTokens(tokens, {
      notification: {
        title: "🎰 התור שלך!",
        body: `התור שלך לבחור אלופה (סבב ${round}). יש לך זמן עד שהגלגל יסובב שוב.`,
      },
      data: { tag: "roulette-turn", url: "/", type: "roulette" },
    });

    logger.info(`Roulette notification sent`, result);
  }
);

// ================================================================
// 3. scheduledMatchReminders - Every 5 min, alert 30min before match
// ================================================================
// Sends to players who haven't yet predicted matches starting in 25-35 min
exports.scheduledMatchReminders = onSchedule(
  { schedule: "every 5 minutes", timeZone: "Asia/Jerusalem" },
  async (event) => {
    const now = Date.now();
    const windowStart = now + 25 * 60 * 1000;
    const windowEnd = now + 35 * 60 * 1000;

    // Get matches data
    const matchesSnap = await db.ref("/state/matches").once("value");
    const matches = matchesSnap.val() || {};

    // Find matches starting in the window
    const matchesToRemind = [];
    for (const matchId of Object.keys(matches)) {
      const m = matches[matchId];
      if (!m.kickoff) continue;
      const ko = typeof m.kickoff === "number" ? m.kickoff : Date.parse(m.kickoff);
      if (isNaN(ko)) continue;
      if (ko >= windowStart && ko <= windowEnd) {
        // Check we haven't already sent for this match
        const sentSnap = await db.ref(`/state/notifSent/matchReminder/${matchId}`).once("value");
        if (sentSnap.exists()) continue;
        matchesToRemind.push({ matchId, ...m });
      }
    }

    if (!matchesToRemind.length) {
      logger.debug("No matches in reminder window");
      return;
    }

    logger.info(`Found ${matchesToRemind.length} matches to remind about`);

    // Get all players
    const playersSnap = await db.ref("/players").once("value");
    const players = playersSnap.val() || {};

    // Get all predictions
    const predictionsSnap = await db.ref("/predictions").once("value");
    const predictions = predictionsSnap.val() || {};

    for (const match of matchesToRemind) {
      // Find players who haven't predicted this match
      const playersToNotify = [];
      for (const pid of Object.keys(players)) {
        const userPredictions = predictions[pid] || {};
        if (!userPredictions[match.matchId]) {
          playersToNotify.push(pid);
        }
      }

      if (!playersToNotify.length) {
        // Mark as sent (no one to notify)
        await db.ref(`/state/notifSent/matchReminder/${match.matchId}`).set(true);
        continue;
      }

      const tokens = await getTokensForPlayers(playersToNotify, "matchStart");
      if (!tokens.length) {
        await db.ref(`/state/notifSent/matchReminder/${match.matchId}`).set(true);
        continue;
      }

      // Build message
      const team1 = match.homeTeam || match.team1 || "?";
      const team2 = match.awayTeam || match.team2 || "?";
      const result = await sendToTokens(tokens, {
        notification: {
          title: "⚽ משחק מתחיל בעוד 30 דקות",
          body: `${team1} נגד ${team2} — עוד לא ניחשת! לחץ לכניסה מהירה.`,
        },
        data: { tag: `match-${match.matchId}`, url: "/", type: "matchReminder", matchId: match.matchId },
      });

      // Mark as sent
      await db.ref(`/state/notifSent/matchReminder/${match.matchId}`).set({
        sentAt: admin.database.ServerValue.TIMESTAMP,
        ...result,
      });

      logger.info(`Match ${match.matchId} reminder sent`, result);
    }
  }
);

// ================================================================
// 4. scheduledDailySummary - Daily at 23:00 Israel time
// ================================================================
exports.scheduledDailySummary = onSchedule(
  { schedule: "0 23 * * *", timeZone: "Asia/Jerusalem" },
  async (event) => {
    logger.info("Running daily summary");

    // Get today's date range (Israel time)
    const now = new Date();
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0).getTime();
    const todayEnd = todayStart + 24 * 60 * 60 * 1000;

    // Find matches finished today
    const matchesSnap = await db.ref("/state/matches").once("value");
    const matches = matchesSnap.val() || {};
    const todayMatchIds = [];
    for (const matchId of Object.keys(matches)) {
      const m = matches[matchId];
      if (!m.kickoff || !m.result) continue;
      const ko = typeof m.kickoff === "number" ? m.kickoff : Date.parse(m.kickoff);
      if (ko >= todayStart && ko < todayEnd) {
        todayMatchIds.push(matchId);
      }
    }

    if (!todayMatchIds.length) {
      logger.info("No matches today, skipping daily summary");
      return;
    }

    // Get predictions
    const predictionsSnap = await db.ref("/predictions").once("value");
    const predictions = predictionsSnap.val() || {};

    // Get all players
    const playersSnap = await db.ref("/players").once("value");
    const players = playersSnap.val() || {};

    // For each player, calculate today's correct predictions
    for (const pid of Object.keys(players)) {
      const userPred = predictions[pid] || {};
      let correct = 0;
      let total = 0;

      for (const matchId of todayMatchIds) {
        const userGuess = userPred[matchId];
        if (!userGuess) continue;
        total++;
        const actualResult = matches[matchId].result;
        if (userGuess === actualResult) correct++;
      }

      if (total === 0) continue; // didn't predict any matches today

      const points = correct * 5;
      const tokens = await getTokensForPlayers([pid], "results");
      if (!tokens.length) continue;

      const body = correct === total
        ? `${correct} מתוך ${total} - כל הניחושים נכונים! צברת ${points} נקודות 🔥`
        : `${correct} מתוך ${total} ניחושים נכונים. צברת ${points} נקודות.`;

      await sendToTokens(tokens, {
        notification: { title: "🏆 סיכום היום", body },
        data: { tag: "daily-summary", url: "/", type: "summary" },
      });
    }

    logger.info("Daily summary complete");
  }
);

// ================================================================
// 5. onRoundStart - Tournament phase changes
// ================================================================
// Notify everyone when entering a new round (R2 picks, knockout, etc.)
exports.onRoundStart = onValueUpdated(
  { ref: "/state/tournament/phase" },
  async (event) => {
    const before = event.data.before.val();
    const after = event.data.after.val();

    if (!after || after === before) return;

    // Map phases to friendly messages
    const PHASE_MESSAGES = {
      "roulette-2": {
        title: "🎰 סבב 2 של הרולטה מתחיל!",
        body: "מתחילים בחירת אלופה שנייה. תזכרו - אם הנבחרת תזכה במונדיאל = +10 נקודות!",
      },
      "knockout-r32": {
        title: "🏆 שלב הנוקאאוט מתחיל!",
        body: "שלב הבתים נגמר. מתחילים את 1/16 הגמר - 32 משחקים מכריעים!",
      },
      "knockout-r16": {
        title: "🏆 שמינית הגמר!",
        body: "המומחיות שלכם נבחנת ברמה גבוהה יותר. בהצלחה!",
      },
      "knockout-qf": {
        title: "🏆 רבע הגמר!",
        body: "נכנסים לשלב המכריע - 8 הקבוצות החזקות ביותר.",
      },
      "knockout-sf": {
        title: "🏆 חצי הגמר!",
        body: "4 נבחרות נשארו במאבק על הגביע.",
      },
      "knockout-f": {
        title: "🏆 הגמר!",
        body: "המשחק הגדול של המונדיאל! ניחושים אחרונים.",
      },
    };

    const msg = PHASE_MESSAGES[after];
    if (!msg) {
      logger.info(`Phase changed to ${after} - no notification template`);
      return;
    }

    const tokens = await getAllTokens("roundStart");
    const result = await sendToTokens(tokens, {
      notification: msg,
      data: { tag: `phase-${after}`, url: "/", type: "phase", phase: after },
    });

    logger.info(`Round start notification (${after}) sent`, result);
  }
);
