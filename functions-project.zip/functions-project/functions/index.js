/**
 * Cloud Functions for תחזיות מונדיאל 26
 * Region: europe-west1
 */

const { onValueCreated, onValueUpdated, onValueWritten } = require("firebase-functions/v2/database");
const { onSchedule } = require("firebase-functions/v2/scheduler");
const { setGlobalOptions } = require("firebase-functions/v2");
const admin = require("firebase-admin");
const logger = require("firebase-functions/logger");

admin.initializeApp();
const db = admin.database();
const messaging = admin.messaging();

setGlobalOptions({ region: "europe-west1" });

// MATCHES DATA
const TEAMS = {
  MEX:"מקסיקו", ZAF:"דרום אפריקה", KOR:"דרום קוריאה", CZE:"צ׳כיה",
  CAN:"קנדה", SUI:"שוויץ", QAT:"קטאר", BIH:"בוסניה",
  BRA:"ברזיל", MAR:"מרוקו", SCO:"סקוטלנד", HAI:"האיטי",
  USA:'ארה״ב', PAR:"פרגוואי", AUS:"אוסטרליה", TUR:"טורקיה",
  GER:"גרמניה", ECU:"אקוודור", CIV:"חוף השנהב", CUW:"קוראסאו",
  NED:"הולנד", JPN:"יפן", TUN:"תוניסיה", SWE:"שוודיה",
  BEL:"בלגיה", IRN:"איראן", EGY:"מצרים", NZL:"ניו זילנד",
  ESP:"ספרד", URU:"אורוגוואי", KSA:"ערב הסעודית", CPV:"כף ורדה",
  FRA:"צרפת", SEN:"סנגל", NOR:"נורווגיה", IRQ:"עיראק",
  ARG:"ארגנטינה", AUT:"אוסטריה", ALG:"אלג׳יריה", JOR:"ירדן",
  POR:"פורטוגל", COL:"קולומביה", UZB:"אוזבקיסטן", COD:"קונגו DR",
  ENG:"אנגליה", CRO:"קרואטיה", PAN:"פנמה", GHA:"גאנה"
};

const MATCHES = [
  {id:"M01",h:"ZAF",a:"MEX",t:"2026-06-11T19:00:00Z"},{id:"M02",h:"CZE",a:"KOR",t:"2026-06-12T02:00:00Z"},
  {id:"M03",h:"ZAF",a:"CZE",t:"2026-06-18T16:00:00Z"},{id:"M04",h:"KOR",a:"MEX",t:"2026-06-19T01:00:00Z"},
  {id:"M05",h:"KOR",a:"ZAF",t:"2026-06-25T01:00:00Z"},{id:"M06",h:"MEX",a:"CZE",t:"2026-06-25T01:00:00Z"},
  {id:"M07",h:"BIH",a:"CAN",t:"2026-06-12T19:00:00Z"},{id:"M08",h:"SUI",a:"QAT",t:"2026-06-13T19:00:00Z"},
  {id:"M09",h:"BIH",a:"SUI",t:"2026-06-18T19:00:00Z"},{id:"M10",h:"QAT",a:"CAN",t:"2026-06-18T22:00:00Z"},
  {id:"M11",h:"CAN",a:"SUI",t:"2026-06-24T19:00:00Z"},{id:"M12",h:"QAT",a:"BIH",t:"2026-06-24T19:00:00Z"},
  {id:"M13",h:"MAR",a:"BRA",t:"2026-06-13T22:00:00Z"},{id:"M14",h:"SCO",a:"HAI",t:"2026-06-14T01:00:00Z"},
  {id:"M15",h:"MAR",a:"SCO",t:"2026-06-19T22:00:00Z"},{id:"M16",h:"HAI",a:"BRA",t:"2026-06-20T00:30:00Z"},
  {id:"M17",h:"BRA",a:"SCO",t:"2026-06-24T22:00:00Z"},{id:"M18",h:"HAI",a:"MAR",t:"2026-06-24T22:00:00Z"},
  {id:"M19",h:"PAR",a:"USA",t:"2026-06-13T01:00:00Z"},{id:"M20",h:"TUR",a:"AUS",t:"2026-06-14T04:00:00Z"},
  {id:"M21",h:"AUS",a:"USA",t:"2026-06-19T19:00:00Z"},{id:"M22",h:"PAR",a:"TUR",t:"2026-06-20T03:00:00Z"},
  {id:"M23",h:"USA",a:"TUR",t:"2026-06-26T02:00:00Z"},{id:"M24",h:"AUS",a:"PAR",t:"2026-06-26T02:00:00Z"},
  {id:"M25",h:"CUW",a:"GER",t:"2026-06-14T17:00:00Z"},{id:"M26",h:"ECU",a:"CIV",t:"2026-06-14T23:00:00Z"},
  {id:"M27",h:"CIV",a:"GER",t:"2026-06-20T20:00:00Z"},{id:"M28",h:"CUW",a:"ECU",t:"2026-06-21T00:00:00Z"},
  {id:"M29",h:"GER",a:"ECU",t:"2026-06-25T20:00:00Z"},{id:"M30",h:"CIV",a:"CUW",t:"2026-06-25T20:00:00Z"},
  {id:"M31",h:"JPN",a:"NED",t:"2026-06-14T20:00:00Z"},{id:"M32",h:"TUN",a:"SWE",t:"2026-06-15T02:00:00Z"},
  {id:"M33",h:"SWE",a:"NED",t:"2026-06-20T17:00:00Z"},{id:"M34",h:"JPN",a:"TUN",t:"2026-06-21T04:00:00Z"},
  {id:"M35",h:"NED",a:"TUN",t:"2026-06-25T23:00:00Z"},{id:"M36",h:"SWE",a:"JPN",t:"2026-06-25T23:00:00Z"},
  {id:"M37",h:"EGY",a:"BEL",t:"2026-06-15T19:00:00Z"},{id:"M38",h:"NZL",a:"IRN",t:"2026-06-16T01:00:00Z"},
  {id:"M39",h:"IRN",a:"BEL",t:"2026-06-21T19:00:00Z"},{id:"M40",h:"EGY",a:"NZL",t:"2026-06-22T01:00:00Z"},
  {id:"M41",h:"BEL",a:"NZL",t:"2026-06-27T03:00:00Z"},{id:"M42",h:"IRN",a:"EGY",t:"2026-06-27T03:00:00Z"},
  {id:"M43",h:"CPV",a:"ESP",t:"2026-06-15T16:00:00Z"},{id:"M44",h:"URU",a:"KSA",t:"2026-06-15T22:00:00Z"},
  {id:"M45",h:"KSA",a:"ESP",t:"2026-06-21T16:00:00Z"},{id:"M46",h:"CPV",a:"URU",t:"2026-06-21T22:00:00Z"},
  {id:"M47",h:"ESP",a:"URU",t:"2026-06-27T00:00:00Z"},{id:"M48",h:"KSA",a:"CPV",t:"2026-06-27T00:00:00Z"},
  {id:"M49",h:"SEN",a:"FRA",t:"2026-06-16T19:00:00Z"},{id:"M50",h:"NOR",a:"IRQ",t:"2026-06-16T22:00:00Z"},
  {id:"M51",h:"IRQ",a:"FRA",t:"2026-06-22T21:00:00Z"},{id:"M52",h:"SEN",a:"NOR",t:"2026-06-23T00:00:00Z"},
  {id:"M53",h:"FRA",a:"NOR",t:"2026-06-26T19:00:00Z"},{id:"M54",h:"IRQ",a:"SEN",t:"2026-06-26T19:00:00Z"},
  {id:"M55",h:"ALG",a:"ARG",t:"2026-06-17T01:00:00Z"},{id:"M56",h:"JOR",a:"AUT",t:"2026-06-17T04:00:00Z"},
  {id:"M57",h:"AUT",a:"ARG",t:"2026-06-22T17:00:00Z"},{id:"M58",h:"ALG",a:"JOR",t:"2026-06-23T03:00:00Z"},
  {id:"M59",h:"AUT",a:"ALG",t:"2026-06-28T02:00:00Z"},{id:"M60",h:"ARG",a:"JOR",t:"2026-06-28T02:00:00Z"},
  {id:"M61",h:"COD",a:"POR",t:"2026-06-17T17:00:00Z"},{id:"M62",h:"COL",a:"UZB",t:"2026-06-18T02:00:00Z"},
  {id:"M63",h:"UZB",a:"POR",t:"2026-06-23T17:00:00Z"},{id:"M64",h:"COD",a:"COL",t:"2026-06-24T02:00:00Z"},
  {id:"M65",h:"POR",a:"COL",t:"2026-06-27T23:30:00Z"},{id:"M66",h:"UZB",a:"COD",t:"2026-06-27T23:30:00Z"},
  {id:"M67",h:"CRO",a:"ENG",t:"2026-06-17T20:00:00Z"},{id:"M68",h:"PAN",a:"GHA",t:"2026-06-17T23:00:00Z"},
  {id:"M69",h:"GHA",a:"ENG",t:"2026-06-23T20:00:00Z"},{id:"M70",h:"CRO",a:"PAN",t:"2026-06-23T23:00:00Z"},
  {id:"M71",h:"GHA",a:"CRO",t:"2026-06-27T21:00:00Z"},{id:"M72",h:"ENG",a:"PAN",t:"2026-06-27T21:00:00Z"}
];

const MATCH_BY_ID = {};
MATCHES.forEach(m => { MATCH_BY_ID[m.id] = m; });
const teamName = (code) => TEAMS[code] || code;

// HELPERS
async function getTokensForPlayers(playerIds, prefKey = null) {
  const tokens = [];
  for (const pid of playerIds) {
    const snap = await db.ref(`players/${pid}`).once("value");
    const player = snap.val();
    if (!player) continue;
    if (prefKey && player.notifPrefs?.[prefKey] === false) continue;
    const fcmTokens = player.fcmTokens || {};
    for (const deviceId of Object.keys(fcmTokens)) {
      const t = fcmTokens[deviceId]?.token;
      if (t) tokens.push({ token: t, playerId: pid, deviceId });
    }
  }
  return tokens;
}

async function getAllTokens(prefKey = null) {
  const snap = await db.ref("players").once("value");
  const players = snap.val() || {};
  return getTokensForPlayers(Object.keys(players), prefKey);
}

async function sendToTokens(tokensWithMeta, payload) {
  if (!tokensWithMeta.length) return { sent: 0, failed: 0, cleaned: 0 };
  const tokens = tokensWithMeta.map((t) => t.token);
  let sent = 0, failed = 0, cleaned = 0;
  const BATCH = 500;
  for (let i = 0; i < tokens.length; i += BATCH) {
    const batch = tokens.slice(i, i + BATCH);
    const batchMeta = tokensWithMeta.slice(i, i + BATCH);
    const message = {
      tokens: batch,
      notification: payload.notification,
      data: payload.data || {},
      webpush: {
        fcmOptions: { link: payload.data?.url || "/" },
        notification: {
          icon: "/icons/icon-192.png",
          badge: "/icons/icon-192.png",
          tag: payload.data?.tag || "mondial26",
          requireInteraction: false,
          dir: "rtl",
          lang: "he",
        },
      },
    };
    try {
      const response = await messaging.sendEachForMulticast(message);
      sent += response.successCount;
      failed += response.failureCount;
      for (let j = 0; j < response.responses.length; j++) {
        const result = response.responses[j];
        if (!result.success) {
          const errCode = result.error?.code || "";
          if (errCode.includes("registration-token-not-registered") ||
              errCode.includes("invalid-argument") ||
              errCode.includes("invalid-registration-token")) {
            const meta = batchMeta[j];
            try { await db.ref(`players/${meta.playerId}/fcmTokens/${meta.deviceId}`).remove(); cleaned++; } catch(e){}
          } else {
            logger.warn(`Send failed: ${errCode}`, result.error?.message);
          }
        }
      }
    } catch (e) {
      logger.error("Batch send error", e);
      failed += batch.length;
    }
  }
  return { sent, failed, cleaned };
}

// 1. onAdminBroadcast
exports.onAdminBroadcast = onValueCreated(
  { ref: "/adminBroadcasts/{broadcastId}" },
  async (event) => {
    const broadcastId = event.params.broadcastId;
    const broadcast = event.data.val();
    if (!broadcast || broadcast.status === "sent") return;
    const { title, body, targetPlayers } = broadcast;
    if (!title || !body) return;

    let tokens;
    if (targetPlayers && Array.isArray(targetPlayers) && targetPlayers.length > 0) {
      tokens = await getTokensForPlayers(targetPlayers, "admin");
    } else {
      tokens = await getAllTokens("admin");
    }

    const result = await sendToTokens(tokens, {
      notification: { title, body },
      data: { tag: "admin-msg", url: "/", type: "admin" },
    });

    await db.ref(`/adminBroadcasts/${broadcastId}`).update({
      status: "sent",
      sentAt: admin.database.ServerValue.TIMESTAMP,
      result,
    });
    logger.info(`Broadcast ${broadcastId} complete`, result);
  }
);

// 2. onRoulettePick — "Your turn!"
async function notifyNextInLine(round) {
  const rouletteSnap = await db.ref("/roulette").once("value");
  const roulette = rouletteSnap.val() || {};
  const numbers = roulette[`r${round}Numbers`] || {};
  const picks = roulette[`r${round}Picks`] || {};

  const pendingPlayers = Object.keys(numbers)
    .filter(pid => !(pid in picks))
    .map(pid => ({ pid, num: numbers[pid] }))
    .sort((a, b) => a.num - b.num);

  if (pendingPlayers.length === 0) return;

  const nextPlayer = pendingPlayers[0];
  const tokens = await getTokensForPlayers([nextPlayer.pid], "roulette");
  if (!tokens.length) return;

  const notifKey = `r${round}_${nextPlayer.pid}_${nextPlayer.num}`;
  const sentSnap = await db.ref(`/notifSent/rouletteTurn/${notifKey}`).once("value");
  if (sentSnap.exists()) return;

  await sendToTokens(tokens, {
    notification: {
      title: "🎰 התור שלך!",
      body: `התור שלך לבחור אלופה (סבב ${round}). היכנס לאפליקציה ובחר.`,
    },
    data: { tag: "roulette-turn", url: "/", type: "roulette", round: String(round) },
  });
  await db.ref(`/notifSent/rouletteTurn/${notifKey}`).set({ sentAt: Date.now() });
  logger.info(`Roulette R${round} notif: ${nextPlayer.pid}`);
}

exports.onRoulettePickR1 = onValueWritten(
  { ref: "/roulette/r1Picks/{pid}" },
  async (event) => {
    if (event.data.after.val() && !event.data.before.val()) {
      await notifyNextInLine(1);
    }
  }
);

exports.onRoulettePickR2 = onValueWritten(
  { ref: "/roulette/r2Picks/{pid}" },
  async (event) => {
    if (event.data.after.val() && !event.data.before.val()) {
      await notifyNextInLine(2);
    }
  }
);

exports.onRouletteActivate = onValueUpdated(
  { ref: "/roulette/active" },
  async (event) => {
    if (!event.data.before.val() && event.data.after.val()) {
      const r1EndedSnap = await db.ref("/roulette/r1EndedAt").once("value");
      const round = r1EndedSnap.exists() ? 2 : 1;
      await notifyNextInLine(round);
    }
  }
);

// 3. scheduledMatchReminders - Every 5 min
exports.scheduledMatchReminders = onSchedule(
  { schedule: "every 5 minutes", timeZone: "Asia/Jerusalem" },
  async (event) => {
    const now = Date.now();
    const windowStart = now + 25 * 60 * 1000;
    const windowEnd = now + 35 * 60 * 1000;

    const matchesToRemind = MATCHES.filter(m => {
      const ko = Date.parse(m.t);
      return ko >= windowStart && ko <= windowEnd;
    });

    if (!matchesToRemind.length) return;

    const [playersSnap, picksSnap] = await Promise.all([
      db.ref("/players").once("value"),
      db.ref("/picks").once("value"),
    ]);
    const players = playersSnap.val() || {};
    const allPicks = picksSnap.val() || {};

    for (const match of matchesToRemind) {
      const sentSnap = await db.ref(`/notifSent/matchReminder/${match.id}`).once("value");
      if (sentSnap.exists()) continue;

      const playersToNotify = [];
      for (const pid of Object.keys(players)) {
        if (!players[pid].claimedBy) continue;
        const userPicks = allPicks[pid]?.matches || {};
        if (!userPicks[match.id]) playersToNotify.push(pid);
      }

      if (!playersToNotify.length) {
        await db.ref(`/notifSent/matchReminder/${match.id}`).set({ sentAt: now, note: "no one to notify" });
        continue;
      }

      const tokens = await getTokensForPlayers(playersToNotify, "matchStart");
      if (!tokens.length) {
        await db.ref(`/notifSent/matchReminder/${match.id}`).set({ sentAt: now, note: "no tokens" });
        continue;
      }

      const t1 = teamName(match.h);
      const t2 = teamName(match.a);
      const result = await sendToTokens(tokens, {
        notification: {
          title: "⚽ משחק מתחיל בעוד 30 דקות",
          body: `${t1} נגד ${t2} — עוד לא ניחשת!`,
        },
        data: { tag: `match-${match.id}`, url: "/", type: "matchReminder", matchId: match.id },
      });

      await db.ref(`/notifSent/matchReminder/${match.id}`).set({ sentAt: now, ...result });
      logger.info(`Match ${match.id} reminder`, result);
    }
  }
);

// 4. scheduledDailySummary - Daily at 23:00 IL time
exports.scheduledDailySummary = onSchedule(
  { schedule: "0 23 * * *", timeZone: "Asia/Jerusalem" },
  async (event) => {
    const now = new Date();
    // Israel timezone (UTC+3, no DST during World Cup)
    const israelNow = new Date(now.getTime() + (now.getTimezoneOffset() + 180) * 60000);
    const todayStart = new Date(israelNow.getFullYear(), israelNow.getMonth(), israelNow.getDate(), 0, 0, 0).getTime() - 180 * 60000;
    const todayEnd = todayStart + 24 * 60 * 60 * 1000;

    const resultsSnap = await db.ref("/results").once("value");
    const allResults = resultsSnap.val() || {};

    const todayMatchIds = [];
    for (const match of MATCHES) {
      const ko = Date.parse(match.t);
      if (ko >= todayStart && ko < todayEnd && allResults[match.id]?.result) {
        todayMatchIds.push(match.id);
      }
    }

    if (!todayMatchIds.length) {
      logger.info("No matches today with results");
      return;
    }

    const [picksSnap, playersSnap] = await Promise.all([
      db.ref("/picks").once("value"),
      db.ref("/players").once("value"),
    ]);
    const allPicks = picksSnap.val() || {};
    const players = playersSnap.val() || {};

    for (const pid of Object.keys(players)) {
      if (!players[pid].claimedBy) continue;
      const userPicks = allPicks[pid]?.matches || {};

      let correct = 0;
      let total = 0;
      for (const matchId of todayMatchIds) {
        const userGuess = userPicks[matchId];
        if (!userGuess) continue;
        total++;
        if (userGuess === allResults[matchId].result) correct++;
      }

      if (total === 0) continue;

      const points = correct * 5;
      const tokens = await getTokensForPlayers([pid], "results");
      if (!tokens.length) continue;

      const body = correct === total
        ? `${correct}/${total} - כל הניחושים נכונים! צברת ${points} נקודות 🔥`
        : `${correct}/${total} ניחושים נכונים. צברת ${points} נקודות.`;

      await sendToTokens(tokens, {
        notification: { title: "🏆 סיכום היום", body },
        data: { tag: "daily-summary", url: "/", type: "summary" },
      });
    }
    logger.info("Daily summary complete");
  }
);

// 5. onResultPosted - Knockout phase trigger
exports.onResultPosted = onValueCreated(
  { ref: "/results/{matchId}" },
  async (event) => {
    const result = event.data.val();
    if (!result?.result) return;

    const allResultsSnap = await db.ref("/results").once("value");
    const allResults = allResultsSnap.val() || {};
    const groupMatchesDone = MATCHES.every(m => allResults[m.id]?.result);
    if (!groupMatchesDone) return;

    const sentSnap = await db.ref("/notifSent/knockoutStart").once("value");
    if (sentSnap.exists()) return;

    const tokens = await getAllTokens("roundStart");
    if (!tokens.length) return;

    await sendToTokens(tokens, {
      notification: {
        title: "🏆 שלב הנוקאאוט מתחיל!",
        body: "שלב הבתים נגמר. מתחילים את 1/16 הגמר - 32 משחקים מכריעים!",
      },
      data: { tag: "knockout-start", url: "/", type: "phase" },
    });

    await db.ref("/notifSent/knockoutStart").set({ sentAt: Date.now() });
    logger.info("Knockout start notification sent");
  }
);
