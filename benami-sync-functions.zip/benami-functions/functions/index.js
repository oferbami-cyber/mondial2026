/**
 * syncWorldCupResults — בן עמי · סנכרון תוצאות מונדיאל 2026 מ-football-data.org
 * רץ כל דקה בתקופת הטורניר, כותב ל-Realtime DB:
 *   /results/{matchId}  — תוצאות סופיות של שלב הבתים
 *   /koResults/{key}    — משחקי נוקאאוט (כולל עדכון חי תוך כדי משחק) לתצוגת "מסע"
 *   /elimTeams/{code}   — נבחרות שהודחו בנוקאאוט
 *   /meta/champion      — האלופה (אחרי הגמר)
 *   /meta/serverSync    — חותמת דופק לבדיקה בפאנל הניהול
 *
 * פריסה:
 *   firebase deploy --only functions:syncWorldCupResults
 */
const { onSchedule } = require("firebase-functions/v2/scheduler");
const { logger } = require("firebase-functions");
const admin = require("firebase-admin");

admin.initializeApp({
  databaseURL: "https://benami-mondial2026-e67ab-default-rtdb.europe-west1.firebasedatabase.app"
});

const FD_TOKEN = "5b878828f8a34c8a9f0cdb73c6bb513c"; // football-data.org API token
const FD_URL = "https://api.football-data.org/v4/competitions/WC/matches";

const TOURNAMENT_FROM = Date.parse("2026-06-10T00:00:00Z");
const TOURNAMENT_TO = Date.parse("2026-07-21T00:00:00Z");

// ===== לוח 72 משחקי הבתים (זהה לזה שבאפליקציה) =====
const MATCHES = [
  {id:"M01",h:"ZAF",a:"MEX",t:"2026-06-11T19:00:00Z"},
  {id:"M02",h:"CZE",a:"KOR",t:"2026-06-12T02:00:00Z"},
  {id:"M03",h:"ZAF",a:"CZE",t:"2026-06-18T16:00:00Z"},
  {id:"M04",h:"KOR",a:"MEX",t:"2026-06-19T01:00:00Z"},
  {id:"M05",h:"KOR",a:"ZAF",t:"2026-06-25T01:00:00Z"},
  {id:"M06",h:"MEX",a:"CZE",t:"2026-06-25T01:00:00Z"},
  {id:"M07",h:"BIH",a:"CAN",t:"2026-06-12T19:00:00Z"},
  {id:"M08",h:"SUI",a:"QAT",t:"2026-06-13T19:00:00Z"},
  {id:"M09",h:"BIH",a:"SUI",t:"2026-06-18T19:00:00Z"},
  {id:"M10",h:"QAT",a:"CAN",t:"2026-06-18T22:00:00Z"},
  {id:"M11",h:"CAN",a:"SUI",t:"2026-06-24T19:00:00Z"},
  {id:"M12",h:"QAT",a:"BIH",t:"2026-06-24T19:00:00Z"},
  {id:"M13",h:"MAR",a:"BRA",t:"2026-06-13T22:00:00Z"},
  {id:"M14",h:"SCO",a:"HAI",t:"2026-06-14T01:00:00Z"},
  {id:"M15",h:"MAR",a:"SCO",t:"2026-06-19T22:00:00Z"},
  {id:"M16",h:"HAI",a:"BRA",t:"2026-06-20T00:30:00Z"},
  {id:"M17",h:"BRA",a:"SCO",t:"2026-06-24T22:00:00Z"},
  {id:"M18",h:"HAI",a:"MAR",t:"2026-06-24T22:00:00Z"},
  {id:"M19",h:"PAR",a:"USA",t:"2026-06-13T01:00:00Z"},
  {id:"M20",h:"TUR",a:"AUS",t:"2026-06-14T04:00:00Z"},
  {id:"M21",h:"AUS",a:"USA",t:"2026-06-19T19:00:00Z"},
  {id:"M22",h:"PAR",a:"TUR",t:"2026-06-20T03:00:00Z"},
  {id:"M23",h:"USA",a:"TUR",t:"2026-06-26T02:00:00Z"},
  {id:"M24",h:"AUS",a:"PAR",t:"2026-06-26T02:00:00Z"},
  {id:"M25",h:"CUW",a:"GER",t:"2026-06-14T17:00:00Z"},
  {id:"M26",h:"ECU",a:"CIV",t:"2026-06-14T23:00:00Z"},
  {id:"M27",h:"CIV",a:"GER",t:"2026-06-20T20:00:00Z"},
  {id:"M28",h:"CUW",a:"ECU",t:"2026-06-21T00:00:00Z"},
  {id:"M29",h:"GER",a:"ECU",t:"2026-06-25T20:00:00Z"},
  {id:"M30",h:"CIV",a:"CUW",t:"2026-06-25T20:00:00Z"},
  {id:"M31",h:"JPN",a:"NED",t:"2026-06-14T20:00:00Z"},
  {id:"M32",h:"TUN",a:"SWE",t:"2026-06-15T02:00:00Z"},
  {id:"M33",h:"SWE",a:"NED",t:"2026-06-20T17:00:00Z"},
  {id:"M34",h:"JPN",a:"TUN",t:"2026-06-21T04:00:00Z"},
  {id:"M35",h:"NED",a:"TUN",t:"2026-06-25T23:00:00Z"},
  {id:"M36",h:"SWE",a:"JPN",t:"2026-06-25T23:00:00Z"},
  {id:"M37",h:"EGY",a:"BEL",t:"2026-06-15T19:00:00Z"},
  {id:"M38",h:"NZL",a:"IRN",t:"2026-06-16T01:00:00Z"},
  {id:"M39",h:"IRN",a:"BEL",t:"2026-06-21T19:00:00Z"},
  {id:"M40",h:"EGY",a:"NZL",t:"2026-06-22T01:00:00Z"},
  {id:"M41",h:"BEL",a:"NZL",t:"2026-06-27T03:00:00Z"},
  {id:"M42",h:"IRN",a:"EGY",t:"2026-06-27T03:00:00Z"},
  {id:"M43",h:"CPV",a:"ESP",t:"2026-06-15T16:00:00Z"},
  {id:"M44",h:"URU",a:"KSA",t:"2026-06-15T22:00:00Z"},
  {id:"M45",h:"KSA",a:"ESP",t:"2026-06-21T16:00:00Z"},
  {id:"M46",h:"CPV",a:"URU",t:"2026-06-21T22:00:00Z"},
  {id:"M47",h:"ESP",a:"URU",t:"2026-06-27T00:00:00Z"},
  {id:"M48",h:"KSA",a:"CPV",t:"2026-06-27T00:00:00Z"},
  {id:"M49",h:"SEN",a:"FRA",t:"2026-06-16T19:00:00Z"},
  {id:"M50",h:"NOR",a:"IRQ",t:"2026-06-16T22:00:00Z"},
  {id:"M51",h:"IRQ",a:"FRA",t:"2026-06-22T21:00:00Z"},
  {id:"M52",h:"SEN",a:"NOR",t:"2026-06-23T00:00:00Z"},
  {id:"M53",h:"FRA",a:"NOR",t:"2026-06-26T19:00:00Z"},
  {id:"M54",h:"IRQ",a:"SEN",t:"2026-06-26T19:00:00Z"},
  {id:"M55",h:"ALG",a:"ARG",t:"2026-06-17T01:00:00Z"},
  {id:"M56",h:"JOR",a:"AUT",t:"2026-06-17T04:00:00Z"},
  {id:"M57",h:"AUT",a:"ARG",t:"2026-06-22T17:00:00Z"},
  {id:"M58",h:"ALG",a:"JOR",t:"2026-06-23T03:00:00Z"},
  {id:"M59",h:"AUT",a:"ALG",t:"2026-06-28T02:00:00Z"},
  {id:"M60",h:"ARG",a:"JOR",t:"2026-06-28T02:00:00Z"},
  {id:"M61",h:"COD",a:"POR",t:"2026-06-17T17:00:00Z"},
  {id:"M62",h:"COL",a:"UZB",t:"2026-06-18T02:00:00Z"},
  {id:"M63",h:"UZB",a:"POR",t:"2026-06-23T17:00:00Z"},
  {id:"M64",h:"COD",a:"COL",t:"2026-06-24T02:00:00Z"},
  {id:"M65",h:"POR",a:"COL",t:"2026-06-27T23:30:00Z"},
  {id:"M66",h:"UZB",a:"COD",t:"2026-06-27T23:30:00Z"},
  {id:"M67",h:"CRO",a:"ENG",t:"2026-06-17T20:00:00Z"},
  {id:"M68",h:"PAN",a:"GHA",t:"2026-06-17T23:00:00Z"},
  {id:"M69",h:"GHA",a:"ENG",t:"2026-06-23T20:00:00Z"},
  {id:"M70",h:"CRO",a:"PAN",t:"2026-06-23T23:00:00Z"},
  {id:"M71",h:"GHA",a:"CRO",t:"2026-06-27T21:00:00Z"},
  {id:"M72",h:"ENG",a:"PAN",t:"2026-06-27T21:00:00Z"}
];

// ===== מיפוי נבחרות: TLA של football-data.org / ISO3 / שמות → הקודים שלנו =====
const OUR_CODES = new Set(MATCHES.flatMap(m => [m.h, m.a]));
const TLA_ALIASES = {
  RSA: "ZAF", SAU: "KSA", NLD: "NED", DEU: "GER", DZA: "ALG",
  HTI: "HAI", PRY: "PAR", URY: "URU", HRV: "CRO", PRT: "POR",
  CHE: "SUI", JOR: "JOR", IRQ: "IRQ"
};
const NAME_MAP = {
  "mexico":"MEX","south africa":"ZAF","south korea":"KOR","korea republic":"KOR","republic of korea":"KOR",
  "czech republic":"CZE","czechia":"CZE",
  "canada":"CAN","switzerland":"SUI","qatar":"QAT",
  "bosnia and herzegovina":"BIH","bosnia-herzegovina":"BIH","bosnia & herzegovina":"BIH","bosnia":"BIH",
  "brazil":"BRA","morocco":"MAR","scotland":"SCO","haiti":"HAI",
  "united states":"USA","usa":"USA","united states of america":"USA",
  "paraguay":"PAR","australia":"AUS","turkey":"TUR","turkiye":"TUR","t\u00fcrkiye":"TUR",
  "germany":"GER","ecuador":"ECU","ivory coast":"CIV","cote d'ivoire":"CIV","c\u00f4te d'ivoire":"CIV","c\u00f4te d\u2019ivoire":"CIV",
  "curacao":"CUW","cura\u00e7ao":"CUW",
  "netherlands":"NED","japan":"JPN","tunisia":"TUN","sweden":"SWE",
  "belgium":"BEL","iran":"IRN","ir iran":"IRN","egypt":"EGY","new zealand":"NZL",
  "spain":"ESP","uruguay":"URU","saudi arabia":"KSA","cape verde":"CPV","cabo verde":"CPV",
  "france":"FRA","senegal":"SEN","norway":"NOR","iraq":"IRQ",
  "argentina":"ARG","austria":"AUT","algeria":"ALG","jordan":"JOR",
  "portugal":"POR","colombia":"COL","uzbekistan":"UZB",
  "dr congo":"COD","congo dr":"COD","dr. congo":"COD","democratic republic of the congo":"COD","drc":"COD",
  "england":"ENG","croatia":"CRO","panama":"PAN","ghana":"GHA"
};

function toOurCode(team) {
  if (!team) return null;
  const tla = (team.tla || "").toUpperCase();
  if (OUR_CODES.has(tla)) return tla;
  if (TLA_ALIASES[tla] && OUR_CODES.has(TLA_ALIASES[tla])) return TLA_ALIASES[tla];
  for (const raw of [team.name, team.shortName]) {
    const n = (raw || "").toLowerCase().trim();
    if (NAME_MAP[n]) return NAME_MAP[n];
  }
  return null;
}

// ===== מיפוי שלבים =====
const STAGE_MAP = {
  LAST_32: "R32", ROUND_OF_32: "R32",
  LAST_16: "R16", ROUND_OF_16: "R16",
  QUARTER_FINALS: "QF", SEMI_FINALS: "SF",
  THIRD_PLACE: "3RD", THIRD_PLACE_PLAYOFF: "3RD",
  FINAL: "F"
};

function pair(obj) {
  if (!obj || obj.home == null || obj.away == null) return null;
  return [obj.home, obj.away];
}

// מציאת משחק בתים שלנו לפי נבחרות + תאריך (סובלנות יום קדימה/אחורה לאזורי זמן)
function findOurMatch(c1, c2, utcDate) {
  const d = utcDate.slice(0, 10);
  return MATCHES.find(om => {
    const teamsMatch = (om.h === c1 && om.a === c2) || (om.h === c2 && om.a === c1);
    if (!teamsMatch) return false;
    const base = Date.parse(om.t.slice(0, 10) + "T00:00:00Z");
    const near = [-86400000, 0, 86400000].map(off => new Date(base + off).toISOString().slice(0, 10));
    return near.includes(d);
  });
}

exports.syncWorldCupResults = onSchedule(
  { schedule: "* * * * *", region: "europe-west1", timeoutSeconds: 60, memory: "256MiB", retryCount: 0 },
  async () => {
    const now = Date.now();
    if (now < TOURNAMENT_FROM || now > TOURNAMENT_TO) {
      logger.info("Outside tournament window, skipping");
      return;
    }

    const db = admin.database();
    let data;
    try {
      const res = await fetch(FD_URL, { headers: { "X-Auth-Token": FD_TOKEN } });
      if (!res.ok) throw new Error("HTTP " + res.status);
      data = await res.json();
    } catch (e) {
      logger.error("football-data.org fetch failed:", e.message);
      await db.ref("meta/serverSync").update({ at: now, error: String(e.message) });
      return;
    }

    const matches = data.matches || [];
    const [resultsSnap, koSnap, elimSnap, champSnap] = await Promise.all([
      db.ref("results").get(), db.ref("koResults").get(),
      db.ref("elimTeams").get(), db.ref("meta/champion").get()
    ]);
    const existingResults = resultsSnap.val() || {};
    const existingKo = koSnap.val() || {};
    const existingElim = elimSnap.val() || {};
    const champion = champSnap.val() || null;

    let written = 0;
    const unmatched = [];

    for (const m of matches) {
      const c1 = toOurCode(m.homeTeam);
      const c2 = toOurCode(m.awayTeam);
      const stage = m.stage || "";
      const status = m.status || "";
      const isGroup = stage === "GROUP_STAGE";
      const sc = m.score || {};
      const fullTime = pair(sc.fullTime);
      const regTime = pair(sc.regularTime);
      const extraTime = pair(sc.extraTime);
      const pens = pair(sc.penalties);

      if (!c1 || !c2) {
        if (m.homeTeam?.name && m.awayTeam?.name) unmatched.push(`${m.homeTeam.name} vs ${m.awayTeam.name}`);
        continue;
      }

      // 1) שלב הבתים: כתיבת תוצאה סופית בלבד (מפעילה התראות תוצאה)
      if (isGroup && status === "FINISHED" && fullTime) {
        const ourMatch = findOurMatch(c1, c2, m.utcDate || "");
        if (!ourMatch) { unmatched.push(`GROUP ${c1}-${c2} ${m.utcDate}`); continue; }
        const flipped = ourMatch.h !== c1;
        const hs = flipped ? fullTime[1] : fullTime[0];
        const as = flipped ? fullTime[0] : fullTime[1];
        const result = hs > as ? "1" : (hs < as ? "2" : "X");
        const ex = existingResults[ourMatch.id];
        if (!ex || ex.result !== result || ex.hs !== hs || ex.as !== as) {
          await db.ref(`results/${ourMatch.id}`).set({ result, hs, as, at: now, src: "auto" });
          written++;
          logger.info(`Result ${ourMatch.id}: ${c1} ${fullTime[0]}-${fullTime[1]} ${c2}`);
        }
        // ניקוי התוצאה החיה — המשחק הסתיים
        await db.ref(`liveScores/${ourMatch.id}`).remove();
      }

      // 1ב) שלב הבתים: תוצאה חיה תוך כדי משחק → liveScores (לא מפעיל התראות)
      if (isGroup && ["IN_PLAY", "PAUSED"].includes(status)) {
        const ourMatch = findOurMatch(c1, c2, m.utcDate || "");
        if (ourMatch) {
          const liveFt = fullTime || [0, 0];
          const flipped = ourMatch.h !== c1;
          const hs = flipped ? liveFt[1] : liveFt[0];
          const as = flipped ? liveFt[0] : liveFt[1];
          await db.ref(`liveScores/${ourMatch.id}`).set({ hs, as, status, at: now });
        }
      }

      // 2) נוקאאוט: עדכון koResults גם תוך כדי משחק (תצוגת מסע חיה)
      const koRound = STAGE_MAP[stage] || null;
      const isLiveOrDone = ["IN_PLAY", "PAUSED", "FINISHED"].includes(status);
      if (koRound && isLiveOrDone) {
        // פורמט תואם ל-openfootball: ft = 90 דק', et = אחרי הארכה, pen = פנדלים
        let ft = fullTime, et = null, pen = null;
        if (sc.duration === "EXTRA_TIME" || sc.duration === "PENALTY_SHOOTOUT") {
          ft = regTime || null;
          et = fullTime;
        }
        if (sc.duration === "PENALTY_SHOOTOUT") pen = pens;
        const koKey = `${koRound}_${[c1, c2].sort().join("_")}`;
        const dataKo = {
          round: koRound, t1: c1, t2: c2,
          ft: ft || null, et: et || null, pen: pen || null,
          date: (m.utcDate || "").slice(0, 10) || null,
          time: (m.utcDate || "").slice(11, 16) || null,
          live: status !== "FINISHED",
          at: now
        };
        const ex = existingKo[koKey];
        const changed = !ex ||
          JSON.stringify(ex.ft) !== JSON.stringify(dataKo.ft) ||
          JSON.stringify(ex.et) !== JSON.stringify(dataKo.et) ||
          JSON.stringify(ex.pen) !== JSON.stringify(dataKo.pen) ||
          ex.live !== dataKo.live || ex.t1 !== c1 || ex.t2 !== c2;
        if (changed) {
          await db.ref(`koResults/${koKey}`).set(dataKo);
          written++;
        }
      }

      // 3) הדחות בנוקאאוט (רק כשהמשחק הסתיים)
      if (koRound && status === "FINISHED" && sc.winner && sc.winner !== "DRAW") {
        const loser = sc.winner === "HOME_TEAM" ? c2 : c1;
        if (!existingElim[loser]) {
          await db.ref(`elimTeams/${loser}`).set(true);
          written++;
        }
      }

      // 4) אלופה
      if (stage === "FINAL" && status === "FINISHED" && sc.winner && sc.winner !== "DRAW") {
        const winnerCode = sc.winner === "HOME_TEAM" ? c1 : c2;
        if (champion !== winnerCode) {
          await db.ref("meta/champion").set(winnerCode);
          written++;
          logger.info(`Champion: ${winnerCode}`);
        }
      }
    }

    if (unmatched.length) logger.warn("Unmatched teams/matches:", unmatched.join(" | "));
    await db.ref("meta/serverSync").update({ at: now, written, error: null, src: "football-data.org" });
    logger.info(`Sync done: ${written} writes, ${matches.length} matches scanned`);
  }
);
